import reducer from '../reducers'
import * as types from '../actionTypes'


describe('todos reducer', () => {
    it('should return the initial state', () => {
        expect(reducer(undefined, {})).toEqual(
            {
                nextId: 2,
                data:
                {
                    1: {
                        content: 'Content 1',
                        completed: false
                    }
                }
            }
        )
    })

    it('should handle ADD_TODO', () => {
        expect(
            reducer(
                [],
                {
                    type: "ADD_TODO",
                    text: 'Run the tests'
                }
            )
        ).toBeDefined()
    })
})