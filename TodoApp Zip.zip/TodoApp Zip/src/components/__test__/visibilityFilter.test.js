import React from 'react';
import ReactDOM from 'react-dom';
import { render, cleanup } from '@testing-library/react';
import VisibilityFilter from '../visibilityFilter';



it("render delete and done button without crash", ()=> {
    const div = document.createElement("div");
    ReactDOM.render(<button></button>, div) ;
})

it("render Span tag to show count without crash", ()=> {
    const div = document.createElement("div");
    ReactDOM.render(<span></span>, div) ;
})



