import React from 'react';
import ReactDOM from 'react-dom';
import { render, cleanup } from '@testing-library/react';
import AddTodo from '../addTodo';
import { shallow} from "enzyme";
import {Provider} from 'react-redux';
import store from '../../redux/store';

it("render button without crash", ()=> {
    const div = document.createElement("div");
    ReactDOM.render(<button></button>, div) ;
})

it("render input Text Box without crash", ()=> {
  const div = document.createElement("div");
  ReactDOM.render(<input />, div) ;
})

it("render Span tag without crash", ()=> {
  const div = document.createElement("div");
  ReactDOM.render(<span></span>, div) ;
})

// it("render input Text Box without crash", ()=> {
//   const wrapper = shallow(
//     <Provider store={store}>
//       <AddTodo />
//     </Provider>
//   );

//   const btn = wrapper.find("button");
//   btn.simulate("click");
//   const total2 = wrapper.find("#addTask").get(0).value;
//   expect(total2).toBe("1");

// })